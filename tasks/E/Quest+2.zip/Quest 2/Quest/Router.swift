import UIKit
import QuestCore

final class Router {
  private let navigationController: UINavigationController

  init(navigationController: UINavigationController) {
    self.navigationController = navigationController
  }

  func showStep(_ step: Step) {
    let (identifier, sender) = { () -> (String, Any) in
      switch step {
      case .branching(let branching):
        return ("showBranching", branching)
      case .bingo(let bingo):
        return ("showBingo", bingo)
      case .deadlock(let deadlock):
        return ("showDeadlock", deadlock)
      case .checkAnswer(let checkAnswer):
        return ("checkAnswer", checkAnswer)
      }
    }()
    navigationController.performSegue(
      withIdentifier: identifier,
      sender: sender
    )
  }
}
