import UIKit

final class TestView: UIView {
  override var canBecomeFirstResponder: Bool { return true }
  override var canResignFirstResponder: Bool { return false }

  override func didMoveToWindow() {
    super.didMoveToWindow()

    becomeFirstResponder()
  }
}
