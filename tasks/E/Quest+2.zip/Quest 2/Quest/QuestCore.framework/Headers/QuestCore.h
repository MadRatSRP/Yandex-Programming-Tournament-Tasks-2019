#import <Foundation/Foundation.h>

FOUNDATION_EXPORT double QuestCoreVersionNumber;
FOUNDATION_EXPORT const unsigned char QuestCoreVersionString[];
