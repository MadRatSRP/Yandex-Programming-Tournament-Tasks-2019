import UIKit
import QuestCore

final class NavigationController: UINavigationController {
  private lazy var router = Router(navigationController: self)

  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    router.showStep(quest)
  }

  override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    switch (segue.destination, sender) {
    case (let branchingVC as BranchingViewController,
          let branching as Branching):
      branchingVC.branching = branching
      branchingVC.router = router
    case (let bingoVC as BingoViewController, let bingo as Bingo):
      bingoVC.bingo = bingo
    case (let deadlockVC as DeadlockViewController, let deadlock as Deadlock):
      deadlockVC.deadlock = deadlock
    case (let textInputVC as TextInputViewController,
          let checkAnswer as CheckAnswer):
      textInputVC.checkAnswer = checkAnswer
      textInputVC.router = router
    default:
      assertionFailure()
    }
  }
}
