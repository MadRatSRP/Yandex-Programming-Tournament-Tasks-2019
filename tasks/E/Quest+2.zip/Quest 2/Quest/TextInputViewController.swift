import UIKit
import QuestCore

final class TextInputViewController: UIViewController {
  var checkAnswer: CheckAnswer!
  var router: Router!

  @IBOutlet private weak var titleLabel: UILabel!
  @IBOutlet private weak var textField: UITextField!

  override func viewDidLoad() {
    super.viewDidLoad()

    titleLabel.text = checkAnswer.title
    textField.addTarget(
      self,
      action: #selector(check),
      for: .editingChanged
    )
  }

  @objc private func check() {
    guard let nextStep = checkAnswer.checkAnswer(textField.text ?? "")
    else { return }

    router.showStep(nextStep)
    textField.resignFirstResponder()
  }
}
