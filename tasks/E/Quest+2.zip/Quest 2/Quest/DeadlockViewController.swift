import UIKit
import QuestCore

final class DeadlockViewController: UIViewController {
  var deadlock: Deadlock!

  @IBOutlet private weak var titleLabel: UILabel!

  override func viewDidLoad() {
    super.viewDidLoad()

    titleLabel.text = deadlock.title
  }
}
