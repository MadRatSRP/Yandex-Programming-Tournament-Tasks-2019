import UIKit
import QuestCore

final class BingoViewController: UIViewController {
  var bingo: Bingo!

  @IBOutlet private weak var titleLabel: UILabel?

  @IBAction private func download(sender: UIButton) {
    bingo.downloadCode { (code) in
      self.titleLabel?.text = code
    }
  }
}
