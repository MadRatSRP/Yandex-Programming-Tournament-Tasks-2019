import UIKit
import QuestCore

final class BranchingViewController: UIViewController {
  var branching: Branching!
  var router: Router!

  override func viewDidLoad() {
    super.viewDidLoad()

    titleLabel.text = branching.title
  }

  @IBOutlet private weak var titleLabel: UILabel!

  @IBAction private func goLeft() {
    router.showStep(branching.left())
  }

  @IBAction private func goRight() {
    router.showStep(branching.left())
  }
}
